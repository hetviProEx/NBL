var mobile = [];
var search = "";
var type = "";
var url = "https://data-extractor.naapbooks.in/api/";//"http://35.154.248.138/api/"; //"http://localhost:8080/api/"; //
chrome.runtime.onMessage.addListener((request, sender) => {
  try {
    if (request.action == "getSource") {
      let alldata = getData(request.source);
      alldata?.length > 0 &&
        fetch(url + type + "/add", {
          method: "POST",
          headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(alldata),
        })
          .then((res) => res.json())
          .then((res) => console.log(res));
      submit.style.display = search ? "block" : "none";
      let s = document.querySelector("#submit2");
      if (type !== "") s.value = "Download all " + type + " Data Excelsheet";
      else s.style.display = "none";
    }
  } catch (error) {
    console.log(error);
  }
});
onWindowLoad = () => {
  try {
    var message = document.querySelector("#message");
    var submit = document.querySelector("#submit");
    submit.style.display = "none";
    chrome.tabs.executeScript(null, { file: "js/getPagesSource.js" }, () => {
      // If you try and inject into an extensions page or the webstore/NTP you'll get an error
      if (chrome.runtime.lastError) {
        message.innerText =
          "There was an error injecting script : \n" +
          chrome.runtime.lastError.message;
      }
    });
  } catch (error) {
    console.log(error);
  }
};
// chrome.extension.onRequest.addListener((request, sender) => {
//   chrome.tabs.update(sender.tab.id, { url: request.redirect });
// });
window.onload = setTimeout(() => {
  this.onWindowLoad();
}, 100);
clickHandler = () => {
  chrome.tabs.update({
    url: url + "get-spreadsheet/" + type + "/" + search.trim(),
  });
  window.close();
};
clickAllHandler = () => {
  chrome.tabs.update({ url: url + "get-spreadsheet/" + type });
  window.close();
};
clickAllofHandler = () => {
  chrome.tabs.update({ url: url + "get-spreadsheet/all" });
  window.close();
};
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("submit").addEventListener("click", clickHandler);
  document.getElementById("submit2").addEventListener("click", clickAllHandler);
  document
    .getElementById("submit3")
    .addEventListener("click", clickAllofHandler);
});
getData = (source) => {
  try {
    let all = source.split("<body");
    let allData = [];
    if (source.search("helloindia.co") !== -1) {
      type = "helloindia";
      message.innerText = "Hello India";
      let arr = all[1]?.split("searrest");
      arr?.forEach((a, j) => {
        if (j > 0) {
          let nm = getArr(a, "repCompanyDetail_hplCompanyName", 1);
          let mob = getArr(a, "repCompanyDetail_lblMobileNo", 1, 2);
          let email = getArr(a, "repCompanyDetail_trEmail", 1);
          let address = getArr(a, "repCompanyDetail_lblAddress", 1);
          let website = getArr(a, "repCompanyDetail_trWebsite", 1);
          let officePhone = getArr(a, "repCompanyDetail_lblofficephone", 1);
          let officePhone2 = getArr(a, "repCompanyDetail_lblcommaof", 1);
          nm?.forEach((b) => {
            let obj = {};
            if (!allData.find((x) => x.name === b) && b.trim() !== "")
              obj.name = b;
            obj.search = search;
            obj = this.getar(mob, "mobile", obj);
            obj = this.getar(officePhone, "officePhone", obj);
            obj = this.getar(officePhone2, "officePhone2", obj);
            if (website && !allData?.find((x) => x.website === website[0]))
              obj.website = website[0];
            if (address[0]?.trim() !== "") obj.address = address[0];
            if (
              email?.trim() !== "" &&
              !allData?.find((x) => x?.email === email)
            )
              obj.email = email;
            obj.name && allData.push(obj);
          });
        } else {
          let sarr = a.split("searchControl$txtcompany");
          search = sarr[1]?.match(new RegExp(/(?<=value=")(.*?)(?=")/))[0];
        }
      });
    } else if (source.search("infoline.com/") !== -1) {
      type = "infoline";
      let blist = all[1]?.split("bussiness_list");
      let sarr = all[1].split("SearchTxtBox");
      search = sarr[1]?.match(new RegExp(/(?<=value=")(.*?)(?=")/))[0];
      let list = blist[1]?.split("<li>");
      list?.forEach((v, i) => {
        if (i > 0) {
          let obj = { search: search };
          let nm = v.match(new RegExp(/(?<=h4>)(.*?)(?=h4)/));
          let name = nm && nm[0]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          obj.name = name && name[0];
          let ad = v.match(new RegExp(/(?<=<p)(.*?)(?=p>)/));
          let add = ad && ad[0]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          obj.address = add && add[0];
          if (v.search("star_des") !== -1) {
            let cn = v?.split(`class="text"`);
            let con = cn[1]?.match(new RegExp(/(?<=>\n)(.*?)(?=<)/));
            allData[allData.length - 1].mobile = con && con[0].trim();
          }
          name && allData.push(obj);
        }
      });
    } else if (source.search("indiamart.com/") !== -1) {
      type = "indiamart";
      let sarr = all[1]?.split("search_string");
      let sr = sarr[1]?.split(">");
      search =
        sr[0]?.includes("value") &&
        sr[0]?.match(new RegExp(/(?<=value=")(.*?)(?=")/))[0];
      if (!search) {
        let src = sarr[1].split("sh-dv");
        search = src[1]?.match(new RegExp(/(?<=<h1>)(.*?)(?=<\/h1>)/))[0];
      }
      let arr = all[1]?.split("CompanyName");
      arr?.forEach((a, j) => {
        if (j > 0) {
          let obj = { search: search.trim() };
          let com = a?.match(new RegExp(/(?<=<span)(.*?)(?=span>)/));
          let comnm = com && com[0]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          if (comnm && comnm[0] !== "" && comnm[0] !== "TrustSEAL Verified")
            obj.name = comnm[0];
          else obj.name = a?.match(new RegExp(/(?<=>)(.*?)(?=<)/))[0];
          let carr = a?.split("Call </span>");
          let num = carr && carr[1]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          if (num) obj.mobile = num[0];
          let ext = a?.split("Ext ");
          if (ext && ext[1])
            obj.extension = ext[1]?.match(new RegExp(/(?<=>)(.*?)(?=<)/))[0];
          let addp = a.split("<!-- -->");
          if (addp && addp[1]) obj.address = addp[1]?.trim();
          else {
            let prew = a.split("pre-wrap");
            addp = prew && prew[1]?.split("<")[0]?.split(">");
            if (addp && addp[1]) obj.address = addp[1]?.trim();
            else {
              let city = a.split("citytt");
              obj.address = city[1]?.split("<")[0]?.split(">")[1]?.trim();
            }
          }
          obj.name && allData.push(obj);
        }
      });
    } else if (source.search("hindustanyellowpages.in") !== -1) {
      type = "hindustanyellowpages";
      search = getSearch(all, "searchControl$txtcompany");
      let arr = all[1]?.split("repCompanyDetail_hplCompanyName_");
      arr?.forEach((a, j) => {
        if (j > 0) {
          let obj = { search: search.trim() };
          let nm = a?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          if (nm && nm[0] !== "") obj.name = nm[0];
          obj.mobile = getSplit(a, "repCompanyDetail_lblMobileNo_");
          obj.mobile2 = getSplit(a, "repCompanyDetail_lblMobileNo2_");
          obj.officePhone = getSplit(a, "repCompanyDetail_lblofficephone_");
          obj.address = getSplit(a, "repCompanyDetail_lblAddress_");
          obj.email = a.split(`href="mailto:`)[1]?.split(`">`)[0];
          obj.gMap = a
            .split(`repCompanyDetail_trContactPerson`)[1]
            ?.split(`href="`)[1]
            ?.split(`" target`)[0];
          obj.name && allData.push(obj);
        }
      });
    } else if (source.search("ibphub.com/") !== -1) {
      type = "ibphub";
      let srch = all[1]
        .split("breadcrumb_keyword")[1]
        ?.match(new RegExp(/(?<=>)(.*?)(?=<)/))[0];
      if (srch && srch !== "AllData") search = srch;
      else {
        all[1].split("breadcrumb")[1]?.split("li>");
        search = search[search.length - 2].replace("</", "");
      }
      let arr = all[1]?.split(`result-name">`);
      arr?.forEach((a, j) => {
        if (j > 0) {
          let obj = { search: search.trim() };
          let nm = a?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
          if (nm && nm[0] !== "") obj.name = nm[0];
          obj.address = getSplit(a, `result-adress"`);
          let mob = a.split(`href="tel:`);
          obj.mobile = getSplit(a, `href="tel:`);
          mob &&
            mob.forEach((b, k) => {
              if (k > 1) obj["mobile" + k] = getSplit(a, `href="tel:`, k);
            });
          if (a.split(`href="tel:`).length > 2)
            obj.mobile2 = getSplit(a, `href="tel:`, 2);
          obj.about = getSplit(a, "search-descr");
          let web = a
            .split("website")?.[1]
            ?.match(new RegExp(/(?<=href=")(.*?)(?=" target)/));
          obj.website =
            web && web && web[0] !== "javascript:void(0);" ? web[0] : "";
          let map = a.split(`direction`)[1]?.split(`href="`)[1]?.split(`"`)[0];
          obj.gMap = map && map !== "javascript:void(0);" ? map : "";
          obj.name && allData.push(obj);
        }
      });
    }
    console.log(allData);
    return allData;
  } catch (error) {
    console.log(error);
  }
};
getSplit = (a, txt, i) => {
  try {
    let mobs = a.split(txt)[i ? i : 1];
    let mb = mobs && mobs?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
    if (mb && mb[0] !== "") return mb[0];
  } catch (error) {
    console.log(error);
  }
};
getSearch = (all, txt) => {
  try {
    let sarr = all[1]?.split(txt);
    let sr = sarr[1]?.split(">");
    let srch =
      sr[0]?.includes("value") &&
      sr[0]?.match(new RegExp(/(?<=value=")(.*?)(?=")/))[0];
    return srch;
  } catch (error) {
    console.log(error);
  }
};
getar = (a, name, obj) => {
  try {
    a?.forEach((c, i) => {
      if (!mobile.includes(c) && c.trim() !== "") {
        mobile.push(c);
        obj[name + (i + 1)] = c;
      }
    });
    return obj;
  } catch (error) {
    console.log(error);
  }
};
getArr = (a, str, inx, ind) => {
  let c_name = a?.split(str);
  let nmarr = c_name[inx]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
  if (str.includes("Email")) {
    let mailto = a?.split("mailto:");
    nmarr = mailto[1]?.split(`">`)[0];
  } else if (str.includes("trWebsite")) {
    nmarr = c_name[inx]?.match(new RegExp(/(?<=target="_blank">)(.*?)(?=<)/));
  } else if (ind) {
    let arr = c_name[ind]?.match(new RegExp(/(?<=>)(.*?)(?=<)/));
    nmarr = nmarr.concat(arr);
  }
  return nmarr;
};
getData1 = (source) => {
  try {
    // let all = source.match(new RegExp("<body" + "(.*)" + "</body>"));
    let all = source.split("<body");
    let arr = all[1].split("lng_cont_name");
    let name = [];
    let number = [];
    let addrs = [];
    arr.forEach((a, j) => {
      if (j > 0) {
        let ab = a.match(new RegExp(/(?<=data-cn=")(.*?)(?=" data-id)/));
        ab.forEach((b) => {
          !name.includes(b) && name.push(b);
        });
        let contact = a.split("contact-info");
        if (contact[1]) {
          let cont = contact[1].split("</p>")[0];
          let mob = cont.split(`"mobilesv `);
          let num = "";
          mob.length > 1 &&
            mob.forEach((c, i) => {
              if (i > 0) {
                if (c.includes("icon-hgd") || c.includes("ji")) num = num + 9;
                else if (c.includes("icon-lkf")) num = num + 8;
                else if (c.includes("icon-acb") || c.includes("icon-tsj"))
                  num = num + 7;
                else if (c.includes("icon-trs")) num = num + 6;
                else if (c.includes("icon-oqp")) num = num + 5;
                else if (c.includes("icon-ikj")) num = num + 4;
                else if (c.includes("icon-poh")) num = num + 3;
                else if (c.includes("icon-nmg")) num = num + 2;
                else if (c.includes("icon-jie")) num = num + 1;
                else if (c.includes("icon-nlm") || c.includes("icon-jie"))
                  num = num + 0;
                if (c.includes(")-")) num = num + ")-";
                else if (c.split("-").length > 2) num = num + "-";
              } else if (c.includes("+(")) num = num + "+(";
              // let mob = a.match(new RegExp(/(?<=mobilesv")(.*?)(?=<\/span>)/));
              // !name.includes(b) && name.push(b);
            });
          if (num !== "") number.push(num);
        } else number.push("");
      }
    });
    let addr = all[1]?.split(`cont_sw_addr">`);
    addr.forEach((b, k) => {
      if (k > 0) {
        ad = b?.split("<")[0]?.trim();
        ad = ad?.replaceAll("\t", "");
        ad = ad?.replaceAll("|", "");
        addrs.push(ad);
      }
    });
    let alldata = [];
    name.forEach((d, i) => {
      alldata.push({ name: d, address: addrs[i], mobile: number[i] });
    });
    return alldata;
  } catch (error) {
    console.log(error);
  }
};
